import type { Config } from '@netlify/functions'

interface Job {
  id: string
  title: string
  company: string
  location: string
  description: string
  tags: string[]
  applyUrl: string
  postedAt: string
  source: string
}

function stripHtml(html: string): string {
  return (html || '')
    .replace(/<[^>]*>/g, ' ')
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&nbsp;/g, ' ')
    .replace(/\s+/g, ' ')
    .trim()
}

async function fetchWithTimeout(url: string, options: RequestInit = {}, ms = 8000): Promise<Response> {
  const controller = new AbortController()
  const timer = setTimeout(() => controller.abort(), ms)
  try {
    const res = await fetch(url, { ...options, signal: controller.signal })
    return res
  } finally {
    clearTimeout(timer)
  }
}

async function fetchRemotive(keywords: string): Promise<Job[]> {
  const primaryKeyword = keywords.split(',')[0].trim()
  const url = `https://remotive.com/api/remote-jobs?search=${encodeURIComponent(primaryKeyword)}&limit=15`
  const res = await fetchWithTimeout(url)
  if (!res.ok) throw new Error(`Remotive HTTP ${res.status}`)
  const data = await res.json() as { jobs?: any[] }
  return (data.jobs || []).slice(0, 12).map((j: any): Job => ({
    id: `remotive-${j.id}`,
    title: j.title || 'Untitled',
    company: j.company_name || 'Unknown',
    location: j.candidate_required_location || 'Worldwide Remote',
    description: stripHtml(j.description || '').slice(0, 700),
    tags: Array.isArray(j.tags) ? j.tags.slice(0, 6) : [],
    applyUrl: j.url || '',
    postedAt: j.publication_date || '',
    source: 'Remotive',
  }))
}

async function fetchArbeitnow(keywords: string): Promise<Job[]> {
  const keywordList = keywords.split(',').map(k => k.trim().toLowerCase()).filter(Boolean)
  const res = await fetchWithTimeout('https://www.arbeitnow.com/api/job-board-api?page=1', {
    headers: { Accept: 'application/json' },
  })
  if (!res.ok) throw new Error(`Arbeitnow HTTP ${res.status}`)
  const data = await res.json() as { data?: any[] }
  return (data.data || [])
    .filter((j: any) => {
      const text = `${j.title || ''} ${(j.tags || []).join(' ')}`.toLowerCase()
      return keywordList.some(kw => text.includes(kw))
    })
    .slice(0, 10)
    .map((j: any): Job => ({
      id: `arbeitnow-${j.slug || j.id || Math.random()}`,
      title: j.title || 'Untitled',
      company: j.company_name || 'Unknown',
      location: j.location || 'Remote',
      description: stripHtml(j.description || '').slice(0, 700),
      tags: Array.isArray(j.tags) ? j.tags.slice(0, 6) : [],
      applyUrl: j.url || '',
      postedAt: j.created_at ? new Date(j.created_at * 1000).toISOString() : '',
      source: 'Arbeitnow',
    }))
}

async function fetchJobicy(keywords: string): Promise<Job[]> {
  const tag = keywords.split(',')[0].trim().split(' ')[0]
  const url = `https://jobicy.com/api/v2/remote-jobs?count=10&tag=${encodeURIComponent(tag)}`
  const res = await fetchWithTimeout(url)
  if (!res.ok) throw new Error(`Jobicy HTTP ${res.status}`)
  const data = await res.json() as { jobs?: any[] }
  return (data.jobs || []).slice(0, 10).map((j: any): Job => ({
    id: `jobicy-${j.id || Math.random()}`,
    title: j.jobTitle || 'Untitled',
    company: j.companyName || 'Unknown',
    location: j.jobGeo || 'Worldwide Remote',
    description: stripHtml(j.jobDescription || j.jobExcerpt || '').slice(0, 700),
    tags: [
      ...(Array.isArray(j.jobIndustry) ? j.jobIndustry : []),
      ...(Array.isArray(j.jobType) ? j.jobType : []),
    ].slice(0, 6),
    applyUrl: j.url || '',
    postedAt: j.pubDate || '',
    source: 'Jobicy',
  }))
}

export default async (req: Request) => {
  const url = new URL(req.url)
  const keywords = url.searchParams.get('keywords') || 'application support, support engineer, .NET'

  const [remotive, arbeitnow, jobicy] = await Promise.allSettled([
    fetchRemotive(keywords),
    fetchArbeitnow(keywords),
    fetchJobicy(keywords),
  ])

  const jobs: Job[] = [
    ...(remotive.status === 'fulfilled' ? remotive.value : []),
    ...(arbeitnow.status === 'fulfilled' ? arbeitnow.value : []),
    ...(jobicy.status === 'fulfilled' ? jobicy.value : []),
  ]

  const sources: Record<string, number | string> = {
    Remotive: remotive.status === 'fulfilled' ? remotive.value.length : `error: ${(remotive.reason as Error)?.message || 'unknown'}`,
    Arbeitnow: arbeitnow.status === 'fulfilled' ? arbeitnow.value.length : `error: ${(arbeitnow.reason as Error)?.message || 'unknown'}`,
    Jobicy: jobicy.status === 'fulfilled' ? jobicy.value.length : `error: ${(jobicy.reason as Error)?.message || 'unknown'}`,
  }

  return Response.json({ jobs, total: jobs.length, sources })
}

export const config: Config = {
  path: '/api/jobs-feed',
}
